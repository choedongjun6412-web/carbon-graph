"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts"
import { TreesIcon, Factory, TrendingUp, Waves } from "lucide-react"

// Generate seasonal CO₂ data (Keeling Curve - one year)
const generateSeasonalData = () => {
  const data = []
  const baseYear = 2024
  for (let month = 0; month < 12; month++) {
    const date = new Date(baseYear, month)
    // Seasonal variation: peaks in May, troughs in October
    const seasonal = 3 * Math.sin(((month - 4) * Math.PI) / 6)
    const value = 422 + seasonal
    data.push({
      month: date.toLocaleDateString("en-US", { month: "short" }),
      co2: Number.parseFloat(value.toFixed(2)),
      description: month >= 3 && month <= 8 ? "Growing season" : "Winter period",
    })
  }
  return data
}

// Generate long-term CO₂ trend data
const generateLongTermData = () => {
  const data = []
  const startYear = 1960
  const endYear = 2024
  for (let year = startYear; year <= endYear; year += 2) {
    // Exponential growth model based on Keeling Curve
    const yearsFromStart = year - startYear
    const value = 315 + yearsFromStart * 1.8 + (yearsFromStart * 0.02) ** 2
    data.push({
      year: year.toString(),
      co2: Number.parseFloat(value.toFixed(2)),
    })
  }
  return data
}

// Generate exponential model data (like GeoGebra)
const generateExponentialModel = () => {
  const data = []
  for (let x = 0; x <= 100; x += 5) {
    const y = 103.7 * Math.pow(0.9986, x) + 0.3 * x + 1
    data.push({
      x,
      y: Number.parseFloat(y.toFixed(2)),
    })
  }
  return data
}

export default function KeelingCurveDashboard() {
  const [activeTab, setActiveTab] = useState("seasonal")
  const seasonalData = generateSeasonalData()
  const longTermData = generateLongTermData()
  const exponentialData = generateExponentialModel()

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      {/* Hero Section */}
      <div className="border-b bg-card">
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-4xl mx-auto text-center space-y-4">
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-balance">
              킬링 곡선 분석과 탄소 포집 기술
            </h1>
            <p className="text-lg text-muted-foreground text-balance">
              대기 중 CO₂ 농도의 계절적 변화와 장기 추세를 이해하고, 기후 위기 완화를 위한 탄소 포집 기술의 효과를
              평가합니다
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 md:py-12">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-chart-1/20 bg-chart-1/5">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-chart-1" />
                Current CO₂
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">422.36 ppm</div>
              <p className="text-xs text-muted-foreground mt-1">Mauna Loa, 2024</p>
            </CardContent>
          </Card>

          <Card className="border-chart-2/20 bg-chart-2/5">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Waves className="h-4 w-4 text-chart-2" />
                Seasonal Range
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">±6 ppm</div>
              <p className="text-xs text-muted-foreground mt-1">Annual variation</p>
            </CardContent>
          </Card>

          <Card className="border-chart-3/20 bg-chart-3/5">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <TreesIcon className="h-4 w-4 text-chart-3" />
                Pine Forest (1ha)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">8.34 t/yr</div>
              <p className="text-xs text-muted-foreground mt-1">CO₂ absorption</p>
            </CardContent>
          </Card>

          <Card className="border-chart-4/20 bg-chart-4/5">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Factory className="h-4 w-4 text-chart-4" />
                Carbon Capture
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1,000 t/yr</div>
              <p className="text-xs text-muted-foreground mt-1">Small unit capacity</p>
            </CardContent>
          </Card>
        </div>

        {/* Interactive Charts */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full max-w-2xl mx-auto grid-cols-3">
            <TabsTrigger value="seasonal">Seasonal Cycle</TabsTrigger>
            <TabsTrigger value="longterm">Long-term Trend</TabsTrigger>
            <TabsTrigger value="model">Mathematical Model</TabsTrigger>
          </TabsList>

          <TabsContent value="seasonal" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">One Year of CO₂ at Mauna Loa</CardTitle>
                <CardDescription className="text-base">
                  대기 중 CO₂ 농도는 1년 주기로 진동합니다. 여름철 식물의 광합성 증가로 CO₂가 감소하고, 겨울철에는
                  광합성 감소와 낙엽 분해로 증가합니다.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[500px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={seasonalData} margin={{ top: 10, right: 30, left: 0, bottom: 20 }}>
                      <defs>
                        <linearGradient id="colorCo2" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.8} />
                          <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0.1} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" strokeOpacity={0.5} />
                      <XAxis dataKey="month" tick={{ fontSize: 14 }} tickMargin={10} />
                      <YAxis
                        domain={[418, 426]}
                        tick={{ fontSize: 14 }}
                        tickMargin={10}
                        label={{
                          value: "CO₂ (ppm)",
                          angle: -90,
                          position: "insideLeft",
                          style: { fontSize: 16, fontWeight: 600 },
                        }}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "2px solid hsl(var(--border))",
                          borderRadius: "8px",
                          padding: "12px",
                          fontSize: "14px",
                        }}
                        labelStyle={{ color: "hsl(var(--foreground))", fontWeight: 600, marginBottom: "4px" }}
                      />
                      <Area
                        type="monotone"
                        dataKey="co2"
                        stroke="hsl(var(--chart-1))"
                        strokeWidth={3}
                        fillOpacity={1}
                        fill="url(#colorCo2)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-4">
              <Card className="bg-chart-3/5 border-chart-3/20">
                <CardHeader>
                  <CardTitle className="text-base">Summer (Growing Season)</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm">식물 광합성이 활발해지면서 대기 중 CO₂를 흡수하여 농도가 감소합니다.</p>
                </CardContent>
              </Card>
              <Card className="bg-chart-5/5 border-chart-5/20">
                <CardHeader>
                  <CardTitle className="text-base">Winter Period</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm">광합성이 감소하고 낙엽 분해가 진행되면서 CO₂ 농도가 증가합니다.</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="longterm" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Long-term CO₂ Trend (1960-2024)</CardTitle>
                <CardDescription className="text-base">
                  산업혁명 이후 인간 활동으로 인한 CO₂ 배출이 지속적으로 증가하면서 대기 중 농도가 급격히 상승하고
                  있습니다.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[500px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={longTermData} margin={{ top: 10, right: 30, left: 0, bottom: 20 }}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" strokeOpacity={0.5} />
                      <XAxis dataKey="year" tick={{ fontSize: 14 }} tickMargin={10} />
                      <YAxis
                        domain={[300, 440]}
                        tick={{ fontSize: 14 }}
                        tickMargin={10}
                        label={{
                          value: "CO₂ (ppm)",
                          angle: -90,
                          position: "insideLeft",
                          style: { fontSize: 16, fontWeight: 600 },
                        }}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "2px solid hsl(var(--border))",
                          borderRadius: "8px",
                          padding: "12px",
                          fontSize: "14px",
                        }}
                        labelStyle={{ color: "hsl(var(--foreground))", fontWeight: 600, marginBottom: "4px" }}
                      />
                      <Line type="monotone" dataKey="co2" stroke="hsl(var(--chart-2))" strokeWidth={4} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-destructive/5 border-destructive/20">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-destructive" />
                  Key Finding
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  1960년대 315ppm에서 2024년 422ppm으로 약 34% 증가했습니다. 이는 인간 활동의 영향을 명확히 보여줍니다.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="model" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Exponential Growth Model</CardTitle>
                <CardDescription className="text-base">
                  GeoGebra를 활용한 CO₂ 농도의 지수적 증가 모델링: f(x) = 103.7 × 0.9986ˣ + 0.3x + 1
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[500px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={exponentialData} margin={{ top: 10, right: 30, left: 0, bottom: 30 }}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" strokeOpacity={0.5} />
                      <XAxis
                        dataKey="x"
                        tick={{ fontSize: 14 }}
                        tickMargin={10}
                        label={{
                          value: "Time (x)",
                          position: "insideBottom",
                          offset: -10,
                          style: { fontSize: 16, fontWeight: 600 },
                        }}
                      />
                      <YAxis
                        tick={{ fontSize: 14 }}
                        tickMargin={10}
                        label={{
                          value: "f(x)",
                          angle: -90,
                          position: "insideLeft",
                          style: { fontSize: 16, fontWeight: 600 },
                        }}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "2px solid hsl(var(--border))",
                          borderRadius: "8px",
                          padding: "12px",
                          fontSize: "14px",
                        }}
                        labelStyle={{ color: "hsl(var(--foreground))", fontWeight: 600, marginBottom: "4px" }}
                      />
                      <Line type="monotone" dataKey="y" stroke="hsl(var(--chart-4))" strokeWidth={4} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Carbon Capture Comparison */}
        <div className="mt-12 space-y-6">
          <div className="text-center space-y-2">
            <h2 className="text-3xl font-bold">Carbon Capture Technology vs Natural Absorbers</h2>
            <p className="text-muted-foreground">탄소 포집 기술과 자연 흡수원의 효과 비교</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="border-chart-3 border-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TreesIcon className="h-6 w-6 text-chart-3" />
                  소나무 숲 (1 hectare)
                </CardTitle>
                <CardDescription>자연 흡수원</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">연간 CO₂ 흡수량</span>
                    <span className="font-bold text-lg">8.34 톤</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">비용</span>
                    <span className="font-bold text-lg">약 300만 원</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">톤당 비용</span>
                    <span className="font-bold text-lg text-chart-3">359,712원</span>
                  </div>
                </div>
                <div className="pt-4 border-t">
                  <p className="text-sm text-muted-foreground">
                    자연 생태계 보전, 생물 다양성 증진, 산소 생산 등 추가적인 환경 편익 제공
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-chart-4 border-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Factory className="h-6 w-6 text-chart-4" />
                  탄소 포집 장치 (소형)
                </CardTitle>
                <CardDescription>기술적 해결책</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">연간 CO₂ 포집량</span>
                    <span className="font-bold text-lg">1,000 톤</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">비용</span>
                    <span className="font-bold text-lg">약 2억 9천만 원</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">톤당 비용</span>
                    <span className="font-bold text-lg text-chart-4">290,000원</span>
                  </div>
                </div>
                <div className="pt-4 border-t">
                  <p className="text-sm text-muted-foreground">
                    흡수량이 소나무의 약 120배로 월등하지만, 높은 초기 비용과 운영 비용 필요
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-primary/5 border-primary/20">
            <CardHeader>
              <CardTitle>결론</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm">
                <strong>단기적 관점:</strong> 현재 기술 수준에서는 자연 흡수원(산림)이 비용 대비 효율적이며 추가적인
                환경 편익도 제공합니다.
              </p>
              <p className="text-sm">
                <strong>장기적 관점:</strong> 탄소 포집 기술의 발전과 상용화가 진행되면 대규모 탄소 감축에 큰 기여를 할
                수 있습니다.
              </p>
              <p className="text-sm font-medium">
                <strong>최적 전략:</strong> 자연 흡수원 보전과 기술적 해결책을 병행하여 탄소 중립 달성을 목표로 해야
                합니다.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Methods Section */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">Carbon Capture Methods</h2>
          <div className="grid md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">연소 후 포집</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">화석 연료 연소 후 배기가스에서 CO₂를 분리하여 포집</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-base">연소 전 포집</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">연료를 연소하기 전에 CO₂를 제거하는 방식</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-base">직접 공기 포집 (DAC)</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  대기 중 CO₂를 직접 포집, 높은 잠재력이지만 상용화 과제 존재
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="border-t mt-16 bg-muted/30">
        <div className="container mx-auto px-4 py-8 text-center text-sm text-muted-foreground">
          <p>Data sources: Mauna Loa Observatory, NOAA Global Monitoring Laboratory</p>
          <p className="mt-2">킬링 곡선 분석 프로젝트 © 2026</p>
        </div>
      </div>
    </div>
  )
}
